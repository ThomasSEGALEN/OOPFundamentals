package fr.campusacademy.oopcourse.demo_10_abstract.model;

public class Tiger extends Catlike {

	@Override
	public void hunt() {

		System.out.println("Graou, hunting like a tiger");
	}

}
