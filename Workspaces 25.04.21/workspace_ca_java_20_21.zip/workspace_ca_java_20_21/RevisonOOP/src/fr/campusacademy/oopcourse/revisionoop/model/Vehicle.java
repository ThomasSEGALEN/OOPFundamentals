package fr.campusacademy.oopcourse.revisionoop.model;

public abstract class Vehicle {

	public void turn() {
		System.out.println("Turning like a vehicle");
	}
	
	public abstract void start();
}
