package fr.campusacademy.oopcourse.revisionoop.model;

public class Car extends Vehicle {

	@Override
	public void start() {
		System.out.println("Start like a car");
	}

}
