package fr.campusacademy.oopcourse.smartphone.model;

public class AndroidPhone extends Smartphone {

	public AndroidPhone(String modelName, int autonomy) {

		super(modelName, autonomy);
	}
}
