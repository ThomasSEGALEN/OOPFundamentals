package fr.campusacademy.oopcourse.demo_9_polymorphism.model;

public class Tiger extends Catlike {

	public void eatHuman() {

		System.out.println("Tiger eat human");
	}

}