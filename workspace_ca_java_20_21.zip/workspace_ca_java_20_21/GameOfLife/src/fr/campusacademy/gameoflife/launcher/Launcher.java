package fr.campusacademy.gameoflife.launcher;

public class Launcher {

	public static void main(String[] args) {

	}

}
