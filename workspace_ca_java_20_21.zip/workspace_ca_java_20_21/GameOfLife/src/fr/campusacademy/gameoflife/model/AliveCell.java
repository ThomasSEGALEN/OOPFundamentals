package fr.campusacademy.gameoflife.model;

public class AliveCell implements Cell {

	@Override
	public Cell newGeneration(int nbNeighbours) {

		return null;
	}

	@Override
	public String getAsString() {

		return "0";
	}

	@Override
	public boolean isAlive() {

		return false;
	}

	
}
