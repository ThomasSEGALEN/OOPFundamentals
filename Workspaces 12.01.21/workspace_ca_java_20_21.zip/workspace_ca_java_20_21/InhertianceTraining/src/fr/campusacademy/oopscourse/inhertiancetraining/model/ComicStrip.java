package fr.campusacademy.oopscourse.inhertiancetraining.model;

public class ComicStrip extends Book {

	@Override
	public void tellStory() {
		System.out.println("I am telling a ComicStrip story");
	}

}
