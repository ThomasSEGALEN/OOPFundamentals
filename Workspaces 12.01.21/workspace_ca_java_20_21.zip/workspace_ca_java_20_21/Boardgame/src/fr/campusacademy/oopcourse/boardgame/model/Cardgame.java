package fr.campusacademy.oopcourse.boardgame.model;

public class Cardgame extends Boardgame {

	public Cardgame() {

		super();
	}

	public Cardgame(int nbOfPlayers, String name, Box box) {

		super(nbOfPlayers, name, box);
	}

}