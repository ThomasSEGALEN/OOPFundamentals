package fr.campusacademy.oopcourse.smartphone.model;

public class IPhone extends Smartphone {

	public IPhone(String string) {

	}

}
