package fr.campusacademy.gameoflifecorrection.launcher;

import java.util.Scanner;

import fr.campusacademy.gameoflifecorrection.exception.TooHighValueException;
import fr.campusacademy.gameoflifecorrection.exception.TooLowValueException;
import fr.campusacademy.gameoflifecorrection.model.World;

public class Launcher {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

//		boolean isCorrectColumnNumber = false;
		int columnInt = 0;
		
		while (columnInt < 5 || columnInt > 40) {
			System.out.println("Please enter the number of columns of the world:");
			System.out.println("> Between 5 and 40 <");
			String columnStr = scanner.nextLine();

			try {
				columnInt = Integer.parseInt(columnStr);
//				isCorrectColumnNumber = true;
			} catch (NumberFormatException e) {
				System.out.println("Input is not valid");
			}
		}

//		boolean isCorrectRowNumber = false;
		int rowInt = 0;
		
		while (rowInt < 5 || rowInt > 40) {
			System.out.println("Please enter the number of rows of the world:");
			System.out.println("> Between 5 and 40 <");
			String rowStr = scanner.nextLine();

			try {
				rowInt = Integer.parseInt(rowStr);
//				isCorrectRowNumber = false;
			} catch (NumberFormatException e) {
				System.out.println("Input is not valid");
			}
		}

		World myWorld = null;
		
		try {
		myWorld = new World(rowInt, columnInt);
		} catch (TooLowValueException e) {
			System.out.println("Please enter values above 5");
			return;
		} catch (TooHighValueException e) {
			System.out.println("Please enter values below 40");
			return;
		}
		
		System.out.println(myWorld);

		while (true) {
			System.out.println("New Generation");

			myWorld.newGeneration();
			System.out.println(myWorld);

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}