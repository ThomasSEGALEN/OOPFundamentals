package fr.campusacademy.gameoflifecorrection.exception;

public class TooLowValueException extends Exception {

}
