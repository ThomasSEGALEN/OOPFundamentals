package fr.campusacademy.gameoflifecorrection.exception;

public class TooHighValueException extends Exception {

}
