package fr.campusacademy.oopcourse.reviewoopproject.model;

public class Screwdriver extends Tool {

	public void repair() {
		
		System.out.println("Repairing like a Screwdriver");	
	}	
}
