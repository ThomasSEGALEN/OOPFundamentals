package fr.campusacademy.oopcourse.demo_7_inheritance_catlike.model;

public class Cat extends CatLike {

	public Cat() {

	}

	public Cat(String name, String color, float weight) {

		super(name, color, weight);
	}

}
