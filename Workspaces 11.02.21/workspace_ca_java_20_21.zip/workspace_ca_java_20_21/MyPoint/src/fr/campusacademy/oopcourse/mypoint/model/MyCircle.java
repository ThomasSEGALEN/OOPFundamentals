package fr.campusacademy.oopcourse.mypoint.model;

public class MyCircle {
	private MyPoint center;
	private int radius;

	public MyCircle() {
		this.center = new MyPoint(0, 0);
		this.radius = 1;
	}

	public MyCircle(MyPoint int x, int y, int radius) {
		center = new MyPoint(x, y);
		this.radius = radius;
	}
	
	public MyCircle(MyPoint center, int radius) {
		super();
		this.center = center;
		this.radius = radius;
	}

	public MyPoint getCenter() {
		return center;
	}

	public void setCenter(MyPoint center) {
		this.center = center;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	public MyPoint getCenterX() {
		return center;
	}

	public void setCenterX(MyPoint center) {
		this.center = center.getX();
	}
	
	public MyPoint getCenterY() {
		return center;
	}

	public void setCenterY(MyPoint center) {
		this.center = center.getY();
	}
	
	public MyPoint[] getCenterXY() {
		return new MyPoint[] {x, y};
	}

	public void setCenterXY(MyPoint center) {
		this.center = center.getX();
		this.center = center.getY();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "MyCircle[center: " + center + ", radius: " + radius + "]";
	}

	public double getArea() {
		return Math.PI * Math.pow(radius, 2);
	}

	public double getCricumference() {
		return Math.PI * 2 * radius;
	}

	public double distance(MyCircle another) {
		return center.distance(another.center);
	}
}
