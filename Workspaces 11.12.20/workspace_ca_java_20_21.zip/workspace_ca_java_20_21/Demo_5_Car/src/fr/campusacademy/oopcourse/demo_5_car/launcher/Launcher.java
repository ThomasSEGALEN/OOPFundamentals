package fr.campusacademy.oopcourse.demo_5_car.launcher;

import fr.campusacademy.oopcourse.demo_5_car.model.Car;

public class Launcher {

	public static void main(String[] args) {

		Car.nbOfWheels = 6;
		Car.printAllCarBrand();

		Car myCar1 = new Car();
		myCar1.color = "Yellow";
		myCar1.price = 59000.0;
		myCar1.brand = "BMW";

		myCar1.stopEngine();
		myCar1.startEngine();

		Car myCar2 = new Car();
		myCar2.color = "Blue";
		myCar2.price = 28000.0;
		myCar2.brand = "Renault";

		myCar2.startEngine();
		myCar2.stopEngine();

		Car myCar3 = new Car("Grey", 15000.0, "Fiat");
		myCar3.startEngine();
		myCar3.stopEngine();
		
		Car myCar4 = new Car("Peugeot");
		myCar4.startEngine();
		myCar4.stopEngine();
	}

}