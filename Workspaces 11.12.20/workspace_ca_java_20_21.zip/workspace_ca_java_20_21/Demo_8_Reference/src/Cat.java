public class Cat {

	String color;

	public Cat(String color) {

		this.color = color;
	}

}