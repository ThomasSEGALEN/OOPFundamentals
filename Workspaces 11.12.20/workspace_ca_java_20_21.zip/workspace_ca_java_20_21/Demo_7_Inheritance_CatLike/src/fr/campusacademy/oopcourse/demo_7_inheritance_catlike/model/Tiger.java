package fr.campusacademy.oopcourse.demo_7_inheritance_catlike.model;

public class Tiger extends CatLike {

	public Tiger() {

	}

	public Tiger(String name, String color, float weight) {

		super(name, color, weight);
	}

}
