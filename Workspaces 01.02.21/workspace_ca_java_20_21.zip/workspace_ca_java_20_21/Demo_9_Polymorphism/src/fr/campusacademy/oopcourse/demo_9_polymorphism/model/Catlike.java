package fr.campusacademy.oopcourse.demo_9_polymorphism.model;

public class Catlike {

	public void sleep() {

		System.out.println("Catlike sleeping");
	}

}