package fr.campusacademy.oopcourse.demo_9_polymorphism.model;

public class Cat extends Catlike {

	public void eatCatFood() {

		System.out.println("Cat is eating catfood");
	}

}