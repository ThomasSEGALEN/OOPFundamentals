
public class Cat {

	public int age;
	public String color;
	
}
