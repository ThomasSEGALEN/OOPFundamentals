package fr.campusacademy.oopcourse.reviewoopproject.model;

public abstract class Tool {

	public void repair() {
		
		System.out.println("Repairing like a tool");
	}
}
