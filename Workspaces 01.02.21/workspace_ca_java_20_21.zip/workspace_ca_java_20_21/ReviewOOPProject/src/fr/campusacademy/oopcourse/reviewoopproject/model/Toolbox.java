package fr.campusacademy.oopcourse.reviewoopproject.model;

public class Toolbox {

	private Tool[] tools = new Tool[5];
	
//	private Hammer hammer;
//	private Screwdriver screwdriver;
//	private Tool randomTool;	
}
