package fr.campusacademy.oopcourse.reviewoopproject.model;

public class Hammer extends Tool {

	public void repair() {
		
		System.out.println("Repairing like a Hammer");
	}
}
