package fr.campusacademy.oopcourse.demo_10_abstract.model;

public interface Animal {

	void sleep();
	void play();
}