package fr.campusacademy.oopcourse.exception.model;

public class MyCustomException extends Exception {

}
