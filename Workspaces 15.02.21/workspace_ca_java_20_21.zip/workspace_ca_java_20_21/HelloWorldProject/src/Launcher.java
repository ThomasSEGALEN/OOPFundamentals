public class Launcher {

	public static void main(String[] args) {
		// starting point
		System.out.println("Hello World");
	}

}