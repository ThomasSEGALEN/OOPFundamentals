package fr.campusacademy.oopcourse.boardgame.model;

public class RolePlayingGame extends Boardgame {

	public RolePlayingGame() {

		super();
	}

	public RolePlayingGame(int nbOfPlayers, String name, Box box) {

		super(nbOfPlayers, name, box);
	}

}