package fr.campusacademy.oopscourse.inhertiancetraining.model;

public class Novel extends Book {

	@Override
	public void tellStory() {
		System.out.println("I am telling a Novel story");
	}

}
